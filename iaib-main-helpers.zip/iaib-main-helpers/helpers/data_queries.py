def query_records(antecedent, consequent, data):
    query_antecedent = ' and '.join(antecedent)
    query_consequent = ' and '.join(consequent)
    antecedent_records = data.query(query_antecedent).describe().iloc[0, 0]
    consequent_records = data.query(query_consequent).describe().iloc[0, 0]
    contain_both = data.query(query_antecedent + ' and ' + query_consequent).describe().iloc[0, 0]
    all_records = data.describe().iloc[0, 0]
    return antecedent_records, consequent_records, contain_both, all_records


def find_antecedent_and_consequent_parts(rule, attributes, function):
    antecedent = []
    consequent = []
    for counter, r in enumerate(rule):
        antecedent, consequent = function(rule, r, attributes, counter, antecedent, consequent)
    return antecedent, consequent


def antecedent_consequent_mob_arm(rule, r, attributes, counter, antecedent, consequent):
    if r != 0 and counter > 0:
        if rule[0] > counter:
            query = "@data." + attributes[counter - 1] + ".id" + " == " + str(r)
            antecedent.append(query)
        else:
            query = "@data." + attributes[counter - 1] + ".id" + " == " + str(r)
            consequent.append(query)
    return antecedent, consequent


def antecedent_consequent_mocanar(_, r, attributes, counter, antecedent, consequent):
    if r[0] == 1:
        query = str(r[1]) + " <= " + attributes[counter] + " <= " + str(r[2])
        antecedent.append(query)
    if r[0] == 2:
        query = str(r[1]) + " <= " + attributes[counter] + " <= " + str(r[2])
        consequent.append(query)
    return antecedent, consequent


def antecedent_consequent_aco_r(_, r, attributes, counter, antecedent, consequent):
    if 0.0 <= r[0] <= 0.33:
        query = str(r[1] - r[2]) + " <= " + attributes[counter] + " <= " + str(r[1] + r[2])
        antecedent.append(query)
    if 0.34 <= r[0] <= 0.66:
        query = str(r[1] - r[2]) + " <= " + attributes[counter] + " <= " + str(r[1] + r[2])
        consequent.append(query)
    return antecedent, consequent


def antecedent_consequent_mopar(_, r, attributes, counter, antecedent, consequent):
    if 0.0 <= r[0] <= 0.33:
        query = str(r[1]) + " <= " + attributes[counter] + " <= " + str(r[2])
        antecedent.append(query)
    if 0.34 <= r[0] <= 0.66:
        query = str(r[1]) + " <= " + attributes[counter] + " <= " + str(r[2])
        consequent.append(query)
    return antecedent, consequent
