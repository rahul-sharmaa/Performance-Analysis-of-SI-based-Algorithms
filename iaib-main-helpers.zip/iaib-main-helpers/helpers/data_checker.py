import random


def check_locations_with_concrete_values(rule, locations):
    ones = locations.count(1)
    twos = locations.count(2)
    if ones == 0 and twos > 1:
        rule = fix_locations_with_concrete_values(rule, 2, 1)
    elif ones == 0:
        rule = fix_locations_with_concrete_values(rule, 0, 1)

    if twos == 0 and ones > 1:
        rule = fix_locations_with_concrete_values(rule, 1, 2)
    elif twos == 0:
        rule = fix_locations_with_concrete_values(rule, 0, 2)
    return rule


def fix_locations_with_concrete_values(rule, to_replace, replace_with):
    for r in rule:
        if r[0] == to_replace:
            r[0] = replace_with
            return rule


def check_locations_with_value_range(rule, locations):
    ones = locations.count(1)
    twos = locations.count(2)
    if ones == 0 and twos > 1:
        rule = fix_locations_with_value_range(rule, (0.34, 0.66), (0, 0.33))
    elif ones == 0:
        rule = fix_locations_with_value_range(rule, (0.67, 1), (0, 0.33))

    if twos == 0 and ones > 1:
        rule = fix_locations_with_value_range(rule, (0, 0.33), (0.34, 0.66))
    elif twos == 0:
        rule = fix_locations_with_value_range(rule, (0.67, 1), (0.34, 0.66))
    return rule


def fix_locations_with_value_range(rule, to_replace, replace_with):
    for r in rule:
        if to_replace[0] <= r[0] <= to_replace[1]:
            r[0] = round(random.uniform(replace_with[0], replace_with[1]), 2)
            return rule


def find_locations_with_value_range(rule):
    location_list = []
    for r in rule:
        if r[0] <= 0.33:
            location_list.append(1)
        elif r[0] <= 0.66:
            location_list.append(2)
        else:
            location_list.append(0)
    return location_list


def fix_locations(rule, f_fix_condition, f_location_replace, data_or_lb, attributes_or_ub):
    for c, r in enumerate(rule):
        if f_fix_condition(r, c, rule):
            return f_location_replace(rule, c, data_or_lb, attributes_or_ub)


def is_move_location_indicator(r, c, _):
    return r != 0 and c > 0


def is_fix_antecedent(r, c, rule):
    return r == 0 and c < rule[0]


def is_fix_consequent(r, c, rule):
    return r == 0 and c > rule[0]


def fix_location_indicator(rule, c, _, __):
    rule[0] = c + 1
    return rule


def fix_attribute_value(rule, c, lb, ub):
    rule[c] = round(random.randrange(lb[c-1], ub[c-1]))
    return rule
