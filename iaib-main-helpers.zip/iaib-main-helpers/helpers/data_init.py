import pandas as pd
from enum import Enum


class DataLocation(Enum):
    BASKETBALL = "../data/BK.dat"
    QUAKE = "../data/QU.dat"
    BODY_FAT = "../data/FA.dat"
    LONGLEY = "../data/LO.dat"


class DataAttributes(Enum):
    BASKETBALL = ["assists_per_minute", "height", "time_played", "age", "points_per_minute"]
    QUAKE = ["focal_depth", "latitude", "longitude", "richter"]
    BODY_FAT = ["case", "body_fat_Brozek", "body_fat_Siri", "density", "age", "weight", "height", "adiposity",
                "fat_free_weight", "neck_circumference", "chest_circumference", "abdomen_circumference",
                "hip_circumference", "thigh_circumference", "knee_circumference", "ankle_circumference",
                "biceps_circumference", "forearm_circumference", "wrist_circumference"]
    LONGLEY = ["deflator", "GNP", "unemployed", "armed_forces", "population", "year", "employed"]


def data_init(location, attributes):
    data = pd.read_csv(location, names=attributes)
    if location == DataLocation.BODY_FAT.value:
        data = data.drop(["case"], axis=1)
    return data


def define_lb_and_ub(attributes, data):
    lb, ub = [], []
    for i in range(0, len(attributes)):
        lb.append(data.describe().iloc[3][i])
        ub.append(data.describe().iloc[7][i])
    return lb, ub
