import pandas as pd


def discretize_data(data, att):
    data_dict = find_intervals(data, att)
    df_list = []
    att_new = []
    for a in att:
        att_new.append(a + " value")
        att_new.append(a + " interval")
        att_new.append(a + " id")

    for ind in range(0, int(data.describe().iloc[0][0])):
        row = []
        for d_en, d in enumerate(data):
            param = data.iloc[ind, d_en]
            for e in data_dict[d]:
                if e[1][0] <= param < e[1][1]:
                    row.append(round(param, 4))
                    row.append(e[1])
                    row.append(e[0])
        df_list.append(row)

    df1 = pd.DataFrame(df_list, columns=att_new)
    a = df1.columns.str.split(' ', expand=True).values
    df1.columns = pd.MultiIndex.from_tuples([x for x in a])
    return df1


def find_intervals(data, att):
    data_dict = {}
    for c, a in enumerate(att):
        count = 3
        maxim = data.describe().iloc[7][c]
        minim = round(data.describe().iloc[3][c], 4)
        inter = round((maxim - minim) / count, 4)
        c1 = 1
        intervals = []
        for i in range(1, int(count) + 1):
            new_min = round(minim + inter, 4)
            counter = data.query(str(minim) + " <= " + a + " <= " + str(new_min)).describe().iloc[0, 0]
            if counter > 0:
                intervals.append((c1, (minim, new_min)))
                c1 += 1
            minim = round(new_min + 0.0001, 4)
        data_dict[a] = intervals
    return data_dict
