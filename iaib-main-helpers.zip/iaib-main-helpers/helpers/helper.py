import copy
from helpers.data_queries import find_antecedent_and_consequent_parts


def delete_duplicated_rules(rules, function, attributes):
    not_duplicated_rules = []
    not_duplicated_objectives = []
    not_duplicated_agents = []
    for t in rules:
        ant, cons = find_antecedent_and_consequent_parts(t.rule, attributes, function)
        rule = [ant, cons]
        objectives = [t.supp, t.conf, t.comp, t.inter]
        if rule not in not_duplicated_rules and objectives not in not_duplicated_objectives:
            not_duplicated_rules.append(rule)
            not_duplicated_objectives.append(objectives)
            not_duplicated_agents.append(t)
    return not_duplicated_agents


def find_non_dominated(population, f_dominates):
    dominated = []
    if f_dominates == first_rule_dominates_second_mopar:
        for p in population:
            p.dominates_count = 0
    for first in population:
        for second in population:
            if first not in dominated and second not in dominated:
                if f_dominates(second, first):
                    dominated.append(first)
                    if f_dominates == first_rule_dominates_second_mopar:
                        second.dominates_count += 1
                    break
                if f_dominates(first, second):
                    dominated.append(second)
                    if f_dominates == first_rule_dominates_second_mopar:
                        first.dominates_count += 1
    non_dom = []
    for pop in population:
        if pop not in dominated and pop not in non_dom:
            non_dom.append(copy.deepcopy(pop))
    return non_dom


def first_rule_dominates_second_mocanar(first, second):
    supp1, conf1, comp1, inter1 = first.supp, first.conf, first.comp, first.inter
    supp2, conf2, comp2, inter2 = second.supp, second.conf, second.comp, second.inter
    return (supp1 >= supp2 and conf1 >= conf2 and comp1 >= comp2 and inter1 >= inter2) and (
            supp1 > supp2 or conf1 > conf2 or comp1 > comp2 or inter1 > inter2)


def first_rule_dominates_second_mopar(first, second):
    conf1, comp1, inter1 = first.conf, first.comp, first.inter
    conf2, comp2, inter2 = second.conf, second.comp, second.inter
    return dominates_mopar(conf1, comp1, inter1, conf2, comp2, inter2)


def dominates_mopar(conf1, comp1, inter1, conf2, comp2, inter2):
    return (conf1 >= conf2 and comp1 >= comp2 and inter1 >= inter2) and (
            conf1 > conf2 or comp1 > comp2 or inter1 > inter2)


def translate_rule(rule, attributes, f_antecedent_consequent):
    antecedent, consequent = find_antecedent_and_consequent_parts(rule, attributes, f_antecedent_consequent)
    rule = "If " + ' and '.join(antecedent) + ", Then " + ' and '.join(consequent) + "\n"
    return rule
