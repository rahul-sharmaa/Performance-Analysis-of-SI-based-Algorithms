import math
from helpers.data_queries import find_antecedent_and_consequent_parts, query_records


def calculate_objectives(rule, attributes, data, f_antecedent_consequent):
    antecedent_part, consequent_part = find_antecedent_and_consequent_parts(rule,
                                                                            attributes,
                                                                            f_antecedent_consequent)
    antecedent, consequent, both_records, all_records = query_records(antecedent_part, consequent_part, data)
    consequent_attributes = len(consequent_part)
    all_attributes = len(antecedent_part) + consequent_attributes
    return evaluate_objectives(antecedent, consequent, both_records, all_records, consequent_attributes, all_attributes)


def evaluate_objectives(antecedent, consequent, contain_both, all_records, consequent_attributes, all_attributes):
    support = calculate_support(contain_both, all_records)
    confidence = calculate_confidence(antecedent, contain_both)
    comprehensibility = calculate_comprehensibility(consequent_attributes, all_attributes)
    interestingness = calculate_interestingness(antecedent, consequent, contain_both, all_records)
    return support, confidence, comprehensibility, interestingness


def calculate_support(records_that_contain_both, all_records):
    return records_that_contain_both / all_records


def calculate_confidence(antecedent_records, records_that_contain_both):
    if antecedent_records == 0:
        return 0
    return records_that_contain_both / antecedent_records


def calculate_comprehensibility(consequent_attributes, all_attributes):
    return math.log(1 + consequent_attributes) / math.log(1 + all_attributes)


def calculate_interestingness(antecedent_records, consequent_records, records_that_contain_both, all_records):
    if antecedent_records == 0 or consequent_records == 0:
        return 0
    return (records_that_contain_both / antecedent_records) * (records_that_contain_both / consequent_records) * (
            1 - records_that_contain_both / all_records)
